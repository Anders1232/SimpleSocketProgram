# ArgumentAnalizer
Um simples analisador de argumentos  que me é muito útil
